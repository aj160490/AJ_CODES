import * as React from 'react';
import ServerPaginationGrid from './datagrid';

export default function app() {
  return (
    <div>
      <ServerPaginationGrid start="0" end="15" />
    </div>
  );
}
